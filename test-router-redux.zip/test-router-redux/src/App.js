import React from "react";
import {BrowserRouter, Route, Link} from 'react-router-dom';
import * as router from 'react-router-dom';
import "./App.css";
import routes from '../src/Component/routes'
const loading = () => <div className="animated fadeIn pt-3 text-center">Loading...</div>;
function App() {
  return (
    <div className="App">
      <div className='col-lg-12 row '>Router Mapping with redux</div>
      <BrowserRouter>
      <React.Suspense fallback={loading()}>
      <div className='col-lg-12 row mt-50'>
        <div className='col-md-3'>
          <ul>
            <li>
              <Link to='/list'>List</Link>
            </li>
            <li>  
              <Link to='/postform'>Redux Sample</Link>
            </li>
            </ul>
          </div>
         <div className='col-md-9'>
                  {routes.map((route, idx) => {
                    return route.component ? (
                      <Route
                        key={idx}
                        path={route.path}
                        exact={route.exact}
                       // name={route.name}
                        render={props => (
                          <route.component {...props} />
                        )} />
                    ) : (null);
                  })}
                </div>  
          </div>      
               </React.Suspense>
                </BrowserRouter>
      {/* <PostForm /> */}
      {/* <Posts /> */}
    </div>
  );
}

export default App;
