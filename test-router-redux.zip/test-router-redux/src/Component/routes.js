import React from 'react';
const Postform = React.lazy(() =>import('./PostForm'));
const List = React.lazy(() =>import('./List'));

const routes = [
   { path:'/list', exact: true ,component:List,},
   { path:'/postform' , exact: true, component:Postform,},
]

export default routes;