import React, { Component } from "react";

class List extends Component{
   constructor(props){
       super(props);
   }
    render() {
        return (
            <div>
                React-router-dom sample list 
            </div>
        );
    }
}  
export default List;