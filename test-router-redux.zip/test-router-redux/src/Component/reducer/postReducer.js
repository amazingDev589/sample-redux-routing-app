import { FETCH_POST, NEW_POST } from "../action/type";

const initialstate = {
  items: [],
  item: {}
};
export default function (state = initialstate, action) {
  switch (action.type) {
    case FETCH_POST:
     // console.log("fetch")
      return {
        ...state
      };
    case NEW_POST:
     // console.log("new")
      state.items[0]=action.payload
      return {
        ...state,
        //id = action.payload.id
        items: state.items
      };
    case "REMOVE_CART":
     // console.log("remove")

      return {
        ...state,
        items: state.items.filter(post => post.id !== action.payload)
      };
    default:
      return state;
  }
}
