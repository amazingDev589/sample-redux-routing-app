import React, { Component } from "react";

import PropTypes from "prop-types";
import { connect } from "react-redux";
import { fetchpost } from "./action/postAction";
import store from "../store";
import { Button,Col,Form,FormGroup, Input, Label,
  } from 'reactstrap';

class Posts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: []
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }
  componentWillMount() {
    fetchpost();
  }
  remove(post) {
    store.dispatch({ type: "REMOVE_CART", payload: post });
    console.log(this.props.posts);
  }
  handleSubmit(event){  
    event.preventDefault();
  }
  handleChange(event){

  }
  render() {
    const PostItem = this.props.posts.map(post => (
      <ul key={post.id} style={{ flexDirection: "row" }}>
       
          <FormGroup row>
                  <Col md='3'><Label>Email </Label></Col>
                   <Col xs="12" md="9">
                    <Input type='text' value={post.email} name='email' onChange={this.handleChange} />
                  </Col>
                  </FormGroup>
                <FormGroup row><Col md='3'><Label>Company Name </Label></Col> <Col xs="12" md="9">
                <Input type='text' value={post.company.name} name='company_name' onChange={this.handleChange} />
                </Col></FormGroup>
                <Button type="submit" color="primary">Save changes</Button>
      </ul>
    ));
    return (<div>
    <Form className="form-horizontal col-6"  onSubmit={this.handleSubmit}>
    {PostItem}
               
              </Form>
    </div>);
  }
}
Posts.propTypes = {
  fetchpost: PropTypes.func.isRequired,
  posts: PropTypes.array.isRequired
};
const mapStateToProps = state => ({
  posts: state.posts.items
});
export default connect(
  mapStateToProps,
  { fetchpost }
)(Posts);
