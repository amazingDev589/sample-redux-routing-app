import React, { Component } from "react";
import { connect } from "react-redux";
import { createPost } from "./action/postAction";
import store from "../store";
import PropTypes from "prop-types";
import axios from 'axios'
import { Card,CardBody,CardHeader,Col,Input} from 'reactstrap';
import Posts from "./Posts";

class PostForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",list:[],userdropdown:'',user:[],loading:false
    };   
    this.handleChange = this.handleChange.bind(this);
  }
  componentDidMount(){
    axios.get('https://jsonplaceholder.typicode.com/users').then((response)=>{
      this.setState({list:response.data,loading:true})
    }).catch((err)=>{})
  }
 
  handleChange(e) {    
      if(this.state.userdropdown!= '')
        store.dispatch({ type: "REMOVE_CART", payload: this.state.userdropdown });        
        var id = e.target.value !=''?e.target.value:0;
        axios.get(' https://jsonplaceholder.typicode.com/users/'+id+'').then((response)=>{
          this.setState({user:response.data,userdropdown:id});
        }).catch((err)=>{});
        e.preventDefault();
      const object = this.state.user;
      // console.log(object)
      store.dispatch({ type: "NEW_POST", payload: object });      
  }
  
  render() {
    const options = this.state.list.map((value,index)=>{
      return <option key={index} value={value.id}>{value.name}</option>
      });
    return (    
      <div className="App">
      {this.state.loading?
      <div className="row">
        <Col md='1'></Col>
        <Col md='8'>
          <Card mt='50'>
            <CardHeader>
              <Input type='select' name='username' value={this.state.userdropdown} onChange={this.handleChange}>
              <option value=''>Select User</option>
              {options}
              </Input>
            </CardHeader>
            <CardBody>
            <Posts />
            </CardBody>
            </Card>
        </Col><Col md='3'></Col></div>:<div>Loading ..</div>}
    </div>
    );
  }
}
PostForm.propTypes = {
  createPost: PropTypes.func.isRequired
};
export default connect(
  null,
  { createPost }
)(PostForm);
