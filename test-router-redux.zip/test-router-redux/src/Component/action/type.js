export const FETCH_POST='FETCH_POST'
export const NEW_POST='NEW_POST'